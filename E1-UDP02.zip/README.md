# Sprint E1-UDP02 — Ordenação e Retenção de Mensagens UDP

Implementação de um servidor UDP que guarda temporariamente mensagens recebidas fora de ordem e as entrega em cascata quando faltas são recebidas.

Como funciona
- O formato das mensagens é `seq:payload`, por exemplo `1:Olá`.
- O servidor guarda mensagens com `seq > nextExpected` numa estrutura temporária (`buffer`).
- Quando `nextExpected` é recebido, o servidor entrega essa mensagem e verifica o `buffer` para entregar sequências contíguas.
- Se o servidor receber uma mensagem adiantada, responde `waitingfor,<L>` indicando a próxima sequência esperada.

Ficheiros
- `src/UDPServer.java` — servidor UDP com buffer para mensagens fora de ordem.
- `src/UDPClient.java` — cliente que envia mensagens numeradas e retransmite quando o servidor pede.

Compilar
```bash
javac src/UDPServer.java src/UDPClient.java
```

Executar servidor (porta por omissão 9876):
```bash
java -cp src UDPServer [porta]
```

Executar cliente:
```bash
java -cp src UDPClient <host> <porta> <total> [shuffle]
```

Exemplos
- Enviar 10 mensagens em ordem:
```bash
java -cp src UDPClient localhost 9876 10
```
- Enviar 10 mensagens em ordem aleatória (simula out-of-order):
```bash
java -cp src UDPClient localhost 9876 10 shuffle
```

Validação
- Observe que o servidor imprime `DELIVERED <seq> -> <payload>` quando entrega mensagens por ordem.
- O cliente retransmite mensagens quando recebe `waitingfor,<n>` do servidor.

Notas
- Esta implementação é um exemplo pedagógico; para produção: tratar timeouts, limpeza de buffer, confirmação/ACK, e volumes maiores de dados.
