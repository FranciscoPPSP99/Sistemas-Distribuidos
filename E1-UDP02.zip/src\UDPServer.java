import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class UDPServer {
    public static void main(String[] args) throws Exception {
        int port = 9876;
        if (args.length > 0) port = Integer.parseInt(args[0]);

        DatagramSocket socket = new DatagramSocket(port);
        System.out.println("Server listening on port " + port);

        Map<Integer, String> buffer = new ConcurrentHashMap<>();
        int nextExpected = 1;

        byte[] buf = new byte[2048];
        while (true) {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);

            String msg = new String(packet.getData(), 0, packet.getLength()).trim();
            String[] parts = msg.split(":", 2);
            int seq;
            try {
                seq = Integer.parseInt(parts[0]);
            } catch (NumberFormatException e) {
                continue;
            }
            String payload = parts.length > 1 ? parts[1] : "";

            InetAddress addr = packet.getAddress();
            int portClient = packet.getPort();

            if (seq < nextExpected) {
                String resp = "duplicate," + nextExpected;
                socket.send(new DatagramPacket(resp.getBytes(), resp.length(), addr, portClient));
            } else if (seq == nextExpected) {
                System.out.println("DELIVERED " + seq + " -> " + payload);
                nextExpected++;

                while (buffer.containsKey(nextExpected)) {
                    String p = buffer.remove(nextExpected);
                    System.out.println("DELIVERED " + nextExpected + " -> " + p);
                    nextExpected++;
                }

                String resp = "delivered," + nextExpected;
                socket.send(new DatagramPacket(resp.getBytes(), resp.length(), addr, portClient));
            } else { // seq > nextExpected
                buffer.put(seq, payload);
                String resp = "waitingfor," + nextExpected;
                socket.send(new DatagramPacket(resp.getBytes(), resp.length(), addr, portClient));
            }
        }
    }
}
